import {setNavActive } from "./utils.js";
function init(){
    setNavActive();
}
window.onload = init;